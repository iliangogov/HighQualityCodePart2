﻿namespace MatrixPath.Logic.Values.Contracts
{
    public interface ICellValueSequence
    {
        int GetNextCellValue();
    }
}
