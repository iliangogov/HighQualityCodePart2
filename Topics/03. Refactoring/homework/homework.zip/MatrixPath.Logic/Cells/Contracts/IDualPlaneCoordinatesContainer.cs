﻿namespace MatrixPath.Logic.Cells.Contracts
{
    public interface IDualPlaneCoordinatesContainer
    {
        int Row { get; }

        int Col { get; }
    }
}
